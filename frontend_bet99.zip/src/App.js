import { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import axios from 'axios';

const firebaseConfig = {
  apiKey: 'SUA_CHAVE_AQUI',
  authDomain: 'SEU_DOMINIO.firebaseapp.com',
  projectId: 'SEU_PROJECT_ID',
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export default function App() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [user, setUser] = useState(null);
  const [valor, setValor] = useState('');
  const [qrCode, setQrCode] = useState(null);
  const [saldo, setSaldo] = useState(0);

  async function loginOuCadastrar() {
    try {
      const cred = await signInWithEmailAndPassword(auth, email, senha);
      setUser(cred.user);
    } catch {
      const cred = await createUserWithEmailAndPassword(auth, email, senha);
      setUser(cred.user);
    }
  }

  async function gerarPix() {
    const res = await axios.post('https://SEU_BACKEND/render.com/gerar-pix', {
      valor: parseFloat(valor),
      descricao: 'Depósito Bet99',
      email: user.email
    });
    setQrCode(res.data.qr_code_base64);
  }

  async function carregarSaldo() {
    const ref = doc(db, 'users', user.email);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      setSaldo(snap.data().saldo || 0);
    }
  }

  useEffect(() => {
    if (user) {
      const intervalo = setInterval(carregarSaldo, 4000);
      return () => clearInterval(intervalo);
    }
  }, [user]);

  if (!user) {
    return (
      <div className="bg-black text-white min-h-screen flex flex-col items-center justify-center gap-4">
        <h1 className="text-2xl font-bold">Bet99 - Login</h1>
        <input className="p-2 bg-gray-800 rounded" placeholder="Email" onChange={e => setEmail(e.target.value)} />
        <input className="p-2 bg-gray-800 rounded" placeholder="Senha" type="password" onChange={e => setSenha(e.target.value)} />
        <button onClick={loginOuCadastrar} className="bg-green-600 px-4 py-2 rounded">Entrar</button>
      </div>
    );
  }

  return (
    <div className="bg-black text-white min-h-screen p-6">
      <h1 className="text-2xl font-bold">Bem-vindo, {user.email}</h1>
      <p className="mt-2">Saldo: <span className="font-mono">R$ {saldo.toFixed(2)}</span></p>

      <div className="mt-8 max-w-md mx-auto bg-gray-900 p-4 rounded-xl shadow-xl">
        <h2 className="text-xl mb-4">Depositar via PIX</h2>
        <input className="p-2 w-full mb-2 bg-gray-800 rounded" placeholder="Valor" onChange={e => setValor(e.target.value)} />
        <button onClick={gerarPix} className="bg-blue-600 w-full py-2 rounded">Gerar QR Code PIX</button>
        {qrCode && (
          <div className="mt-4">
            <p className="mb-2">Escaneie com seu app de banco:</p>
            <img src={`data:image/png;base64,${qrCode}`} alt="QR Code PIX" className="mx-auto" />
          </div>
        )}
      </div>
    </div>
  );
}